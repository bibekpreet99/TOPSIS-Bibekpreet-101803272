This is a package to find topsis score and rank of a dataframe with only numerical values.

command line usage

python topsis.py "input.csv" "1,1,1,2" "+,+,+,-" "out.csv"